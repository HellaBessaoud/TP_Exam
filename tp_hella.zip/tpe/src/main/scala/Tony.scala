import com.amazonaws.auth.{AWSStaticCredentialsProvider, DefaultAWSCredentialsProviderChain}
object Tony {
  def main(args: Array[String]): Unit = {
    import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder
    import com.amazonaws.services.kinesis.model.PutRecordsRequest
    import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry
    import com.amazonaws.services.kinesis.model.PutRecordsResult
    import java.nio.ByteBuffer
    import java.util
    val credentials = new DefaultAWSCredentialsProviderChain
    val kinesisClient = AmazonKinesisClientBuilder.standard()
      .withCredentials(new AWSStaticCredentialsProvider(credentials.getCredentials))
      .withRegion("eu-west-1").build()
    val putRecordsRequest = new PutRecordsRequest
    putRecordsRequest.setStreamName("tf-kinesis-hella")
    val putRecordsRequestEntryList = new util.ArrayList[PutRecordsRequestEntry]
    for (i <- 0 until 100) {
      val myString : String = "Tony"+i+";"+i+"\n"
      val putRecordsRequestEntry = new PutRecordsRequestEntry
      putRecordsRequestEntry.setData(ByteBuffer.wrap(myString.getBytes))
      putRecordsRequestEntry.setPartitionKey(String.format("test"))
      putRecordsRequestEntryList.add(putRecordsRequestEntry)
    }
    putRecordsRequest.setRecords(putRecordsRequestEntryList)
    val putRecordsResult: PutRecordsResult = kinesisClient.putRecords(putRecordsRequest)
    System.out.println("Put Result" + putRecordsResult)
  }
}